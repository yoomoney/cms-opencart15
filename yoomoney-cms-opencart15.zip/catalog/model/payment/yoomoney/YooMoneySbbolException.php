<?php

class YooMoneySbbolException extends Exception
{

}