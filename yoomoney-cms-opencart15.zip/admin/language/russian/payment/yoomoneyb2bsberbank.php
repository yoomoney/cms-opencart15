<?php
$_['heading_title']    = 'ЮKassa: Сбербанк Бизнес Онлайн';
$_['text_yoomoney'] = '<a onclick="window.open(\'https://yoomoney.ru\');"><img src="view/image/payment/yoomoney.png" alt="ЮMoney" title="ЮMoney" /></a>';
