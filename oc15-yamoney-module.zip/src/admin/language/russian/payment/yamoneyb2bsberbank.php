<?php
$_['heading_title']    = 'Яндекс.Деньги 2.0: Сбербанк Бизнес Онлайн';
$_['text_yandexmoney'] = '<a onclick="window.open(\'https://money.yandex.ru\');"><img src="view/image/payment/yandexmoney.png" alt="Яндекс.Деньги" title="Яндекс.Деньги" /></a>';
