<?php

class YandexMoneySbbolException extends Exception
{

}