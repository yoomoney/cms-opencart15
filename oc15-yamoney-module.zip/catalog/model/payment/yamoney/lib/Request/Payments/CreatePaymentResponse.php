<?php

namespace YaMoney\Request\Payments;

/**
 * Класс объекта ответа возвращаемого API при запросе на создание платежа
 *
 * @package YaMoney\Request\Payments
 */
class CreatePaymentResponse extends AbstractPaymentResponse
{}
