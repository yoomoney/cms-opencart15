<?php

namespace YaMoney\Request\Refunds;

/**
 * Класс объекта ответа от API при создании нового возврата
 *
 * @package YaMoney\Request\Refunds
 */
class CreateRefundResponse extends AbstractRefundResponse
{}
